var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/chooseLibrary.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/chooseLibrary.js":
/*!******************************!*\
  !*** ./src/chooseLibrary.js ***!
  \******************************/
/*! exports provided: default, openSetting */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "openSetting", function() { return openSetting; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

var document = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

var Library = __webpack_require__(/*! sketch/dom */ "sketch/dom").Library;

var libraries = Library.getLibraries();
var libraryIndex = Settings.documentSettingForKey(document, 'selectedLibrary'); // Settings.setDocumentSettingForKey(document, 'selectedLibrary', 'Current local document');

/* harmony default export */ __webpack_exports__["default"] = (function () {
  openSetting();
});
function openSetting(context) {
  var librariesWithIndex = [];

  for (var i = 0; i < libraries.length; i++) {
    librariesWithIndex[i] = {
      name: libraries[i].name,
      index: i
    };
  }

  librariesWithIndex.sort(function (a, b) {
    return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
  });
  var libraryNamesSorted = librariesWithIndex.map(function (x) {
    return x.name;
  });
  libraryNamesSorted.unshift("Current local document");
  librariesWithIndex.unshift({
    name: "Current local document",
    index: 999
  });
  console.log("current index: " + libraryIndex);

  if (!symbolsFromCurrentDoc()) {
    for (var j = 0; j < libraryNamesSorted.length; j++) {
      if (librariesWithIndex[j].index === libraryIndex) {
        var currentLibraryName = libraryNamesSorted[j];
        console.log("found " + currentLibraryName);
        libraryNamesSorted.unshift(currentLibraryName);
        var currentLibrary = librariesWithIndex[j];
        librariesWithIndex.unshift(currentLibrary); //remove found

        libraryNamesSorted.splice(j + 1, 1);
        librariesWithIndex.splice(j + 1, 1);
        break;
      }
    }
  }

  var selection = UI.getSelectionFromUser("Choose UI Library to use with Felipe:", libraryNamesSorted);
  var ok = selection[2];

  if (ok) {
    initAllSettings(); //if current document

    console.log("chosen: " + libraryNamesSorted[selection[1]]);

    if (libraryNamesSorted[selection[1]] === "Current local document") {
      Settings.setDocumentSettingForKey(document, 'selectedLibrary', -1);
      sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Using local symbols from the current document.");
    } //if not current document
    else {
        console.log("chosen library " + librariesWithIndex[selection[1]].name);
        console.log("chosen library index " + librariesWithIndex[selection[1]].index); //TODO: again, use selection index

        Settings.setDocumentSettingForKey(document, 'selectedLibrary', librariesWithIndex[selection[1]].index);
        sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Using '" + libraryNamesSorted[selection[1]] + "' as current symbol library.");
      }
  }
}

function printArray(arr) {
  for (var i = 0; i < arr.length; i++) {
    console.log(arr[i]);
  }
}

var initAllSettings = function initAllSettings() {
  console.log("settings reset");
  Settings.setDocumentSettingForKey(document, 'button', -999);
  Settings.setDocumentSettingForKey(document, 'header', -999);
  Settings.setDocumentSettingForKey(document, 'card', -999);
  Settings.setDocumentSettingForKey(document, 'footer', -999);
  Settings.setDocumentSettingForKey(document, 'checkbox', -999);
  Settings.setDocumentSettingForKey(document, 'radiobutton', -999);
  Settings.setDocumentSettingForKey(document, 'background', -999);
  Settings.setDocumentSettingForKey(document, 'input', -999);
  Settings.setDocumentSettingForKey(document, 'switch', -999);
  Settings.setDocumentSettingForKey(document, 'statusbar', -999);
  Settings.setDocumentSettingForKey(document, 'sidebar', -999);
};

function symbolsFromCurrentDoc() {
  return isNaN(libraryIndex) || libraryIndex === "currentFile" || libraryIndex === undefined || libraryIndex === -1;
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=chooseLibrary.js.map