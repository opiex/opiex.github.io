var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/settings.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/settings.js":
/*!*************************!*\
  !*** ./src/settings.js ***!
  \*************************/
/*! exports provided: default, createWindow */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createWindow", function() { return createWindow; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

var document = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

var Library = __webpack_require__(/*! sketch/dom */ "sketch/dom").Library;

var allLibraries = Library.getLibraries();
var libraryIndex = Settings.documentSettingForKey(document, 'selectedLibrary');
console.log("current index: " + libraryIndex); // console.log("current library: " +allLibraries[libraryIndex].name);

var dropdowns = [];
/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  openSetting(context);
}); //Creates a window

function createWindow(context) {
  var alert = COSAlertWindow.new();
  var plugin = context.plugin;
  var iconPath = plugin.urlForResourceNamed("icon.png").path();
  var icon = NSImage.alloc().initByReferencingFile(iconPath);
  alert.setIcon(icon);
  alert.setMessageText("For each element, you can modify the symbol that will be drawn"); // Creating dialog buttons

  alert.addButtonWithTitle("Apply");
  alert.addButtonWithTitle("Cancel"); // Creating the view

  var viewWidth = 400;
  var viewHeight = 340;
  var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, viewHeight));
  alert.addAccessoryView(view);
  fillAllDropdowns(view);
  return [alert];
}

function fillAllDropdowns(view) {
  var list = "";
  var allDropdowns = returnAllDropdowns();
  var current = 0;

  for (var i = 0; i < 6; i++) {
    for (var j = 0; j < 2; j++) {
      //calculate the label name and the position of the elements
      var name = allDropdowns[current].name;
      var alternativeName = allDropdowns[current].alternativeName;
      var y = 40 + (5 - i) * 58;
      var x = j * 160; //find out the values to populate the dropdown

      list = determineDropdownValues(name, alternativeName); //create UI for the dropdown

      createDropdownUI(view, x, y, 140, 20, name, list, current);

      if (current === 10) {
        return;
      }

      current++;
    }
  }
}

function determineDropdownValues(name, alternativeName) {
  var symbols = [];

  if (symbolsFromCurrentDoc()) {
    symbols = document.getSymbols();
  } else {
    symbols = allLibraries[libraryIndex].getImportableSymbolReferencesForDocument(document);
  }

  var symbolNames = symbols.map(function (x) {
    return x.name;
  });
  var orderedList = arrangeByNames(symbolNames, name, alternativeName);
  return orderedList;
}

var arrangeByNames = function arrangeByNames(symbolNames, name, alternativeName) {
  var originalArray = symbolNames.filter(function (currentName) {
    return ifMatches(currentName, name) === false;
  }); //find matching values to name

  var originalMatch = symbolNames.filter(function (currentName) {
    return ifMatches(currentName, name) === true;
  }); //find matching values to alternative name

  var alternativeMatch = [];

  if (alternativeName !== undefined) {
    originalArray = symbolNames.filter(function (currentName) {
      return ifMatches(currentName, alternativeName) === false;
    });
    alternativeMatch = symbolNames.filter(function (currentName) {
      return ifMatches(currentName, name) === false && ifMatches(currentName, alternativeName) === true;
    });
  } //sort alphabetically


  originalArray.sort(function (a, b) {
    return a.toLowerCase().localeCompare(b.toLowerCase());
  });
  alternativeMatch.sort(function (a, b) {
    return a.toLowerCase().localeCompare(b.toLowerCase());
  });
  originalMatch.sort(function (a, b) {
    return a.toLowerCase().localeCompare(b.toLowerCase());
  }); //create array ordered by name relevance

  var finalArray = originalArray.concat(alternativeMatch).concat(originalMatch); //filter out if it has xx_mixin

  finalArray = finalArray.filter(function (currentName) {
    return ifMatches(currentName, "xx_mixin") === true;
  }); //if current value for the dropdown is defined, put it first

  var currentSelectedSymbol = Settings.documentSettingForKey(document, name);

  if (currentSelectedSymbol !== undefined && currentSelectedSymbol !== -999) {
    var index = finalArray.indexOf(currentSelectedSymbol);
    if (index !== -1) finalArray.splice(index, 1);
    finalArray.unshift(currentSelectedSymbol);
  } else {
    finalArray.unshift('Auto');
  }

  return finalArray;
}; //checks if str2 matches str1


var ifMatches = function ifMatches(str1, str2) {
  return str1.toUpperCase().indexOf(str2.toUpperCase()) === -1;
};

function populateDropdown(list, dropdown) {
  for (var i = 0; i < list.length; i++) {
    dropdown.addItemWithTitle(list[i]);
  }
}

function createDropdownUI(view, x, y, width, height, label, list, i) {
  dropdowns[i].dropdownButton = NSPopUpButton.alloc().initWithFrame(NSMakeRect(x, y - 25, width, height));
  dropdowns[i].name = label;
  var infoLabel = NSTextField.alloc().initWithFrame(NSMakeRect(x, y, width, 15));
  infoLabel.setStringValue(label);
  infoLabel.setSelectable(false);
  infoLabel.setEditable(false);
  infoLabel.setDrawsBackground(false);
  infoLabel.setBezeled(false);
  populateDropdown(list, dropdowns[i].dropdownButton);
  view.addSubview(infoLabel);
  view.addSubview(dropdowns[i].dropdownButton);
} // This function will display the dialog window


function openSetting(context) {
  // Create and show dialog window
  initDropdowns();
  var window = createWindow(context);
  var alert = window[0];
  console.log('setting index: ' + libraryIndex);
  var response = alert.runModal(); // This part shows the dialog windows and stores the 'response' in a variable

  if (response === 1000) {
    for (var i = 0; i < dropdowns.length; i++) {
      var name = dropdowns[i].name;
      var selectedSymbol = String(dropdowns[i].dropdownButton.titleOfSelectedItem()); //check if name different than current setting

      var currentValue = Settings.documentSettingForKey(document, name);

      if (selectedSymbol !== currentValue && selectedSymbol !== 'Auto') {
        console.log('setting ' + selectedSymbol + ' as a the value of ' + name);
        Settings.setDocumentSettingForKey(document, name, selectedSymbol);
      } //if it is, update current setting

    }
  }
}

function initDropdowns() {
  for (var i = 0; i < 11; i++) {
    dropdowns[i] = {};
  }
}

var returnAllDropdowns = function returnAllDropdowns() {
  var allDropdowns = [{
    name: "button",
    alternativeName: "btn"
  }, {
    name: "switch",
    alternativeName: "toggle"
  }, {
    name: "header",
    alternativeName: "hero"
  }, {
    name: "footer",
    alternativeName: "bottom"
  }, {
    name: "checkbox",
    alternativeName: "check box"
  }, {
    name: "radiobutton",
    alternativeName: "radio"
  }, {
    name: "background",
    alternativeName: "bg"
  }, {
    name: "input",
    alternativeName: "textfield"
  }, {
    name: "status bar",
    alternativeName: "status"
  }, {
    name: "sidebar",
    alternativeName: "left"
  }, {
    name: "card",
    alternativeName: "photo"
  }];
  return allDropdowns;
};

function symbolsFromCurrentDoc() {
  return isNaN(libraryIndex) || libraryIndex === "currentFile" || libraryIndex === undefined || libraryIndex === 0;
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=settings.js.map