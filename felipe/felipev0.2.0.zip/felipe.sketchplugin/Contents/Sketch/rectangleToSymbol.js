var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/rectangleToSymbol.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/rectangleToSymbol.js":
/*!**********************************!*\
  !*** ./src/rectangleToSymbol.js ***!
  \**********************************/
/*! exports provided: default, onRectangle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onRectangle", function() { return onRectangle; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

var document = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();

var Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

var Group = __webpack_require__(/*! sketch/dom */ "sketch/dom").Group;

var Library = __webpack_require__(/*! sketch/dom */ "sketch/dom").Library;

var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var allLibraries = Library.getLibraries();
var libraryIndex = Settings.documentSettingForKey(document, 'selectedLibrary');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  onRectangle();
});

function findSymbol(symbols, symbolName, fallbackName) {
  var searchedString = "";
  console.log('symbol name: ' + symbolName);

  if (symbolName !== undefined && symbolName !== -999) {
    searchedString = symbolName.toUpperCase();
  } else {
    searchedString = fallbackName.toUpperCase();
  }

  console.log('searchedString: ' + searchedString);
  var currentString;
  var minLength = 999;
  var relevantSymbol = null;

  for (var i = 0; i < symbols.length; i++) {
    currentString = symbols[i].name.toUpperCase();

    if (currentString.indexOf(searchedString) !== -1 && currentString.length < minLength) {
      minLength = currentString.length;
      relevantSymbol = symbols[i];
    }
  }

  return relevantSymbol;
}

function overrideLayers(layer, instance) {
  instance.parent = layer.parent;
  var diff = instance.index - layer.index;

  for (var i = 0; i < diff; i++) {
    instance.moveBackward();
  }

  layer.remove();
}

function overrideSwitch(rectangle, symbols) {
  console.log("overriding switch");
  var switchSymbolName = Settings.documentSettingForKey(document, 'switch');
  console.log('switch symbol name: ' + switchSymbolName);
  var symbol = findSymbol(symbols, switchSymbolName, "switch-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  overrideLayers(rectangle, instance);
}

function overrideButton(rectangle, symbols) {
  console.log("overriding button");
  var buttonSymbolName = Settings.documentSettingForKey(document, 'button');
  var symbol = findSymbol(symbols, buttonSymbolName, "button-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  overrideLayers(rectangle, instance);
}

function overrideFooter(rectangle, symbols) {
  console.log("overriding footer");
  var footerSymbolName = Settings.documentSettingForKey(document, 'footer');
  var symbol = findSymbol(symbols, footerSymbolName, "footer-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.width = rectangle.parent.frame.width;
  instance.frame.y = rectangle.parent.frame.height - instance.frame.height;
  overrideLayers(rectangle, instance);
}

function overrideHeader(rectangle, symbols) {
  console.log("overriding header");
  var headerSymbolName = Settings.documentSettingForKey(document, 'header');
  var symbol = findSymbol(symbols, headerSymbolName, "header-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  instance.frame.width = rectangle.parent.frame.width;
  overrideLayers(rectangle, instance);
}

function overrideStatusbar(rectangle, symbols) {
  console.log("overriding status bar");
  var statusbarSymbolName = Settings.documentSettingForKey(document, 'statusbar');
  var symbol = findSymbol(symbols, statusbarSymbolName, "statusbar-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  instance.frame.width = rectangle.parent.frame.width;
  overrideLayers(rectangle, instance);
}

function overrideSidebar(rectangle, symbols) {
  console.log("overriding sidebar");
  var sidebarSymbolName = Settings.documentSettingForKey(document, 'sidebar');
  var symbol = findSymbol(symbols, sidebarSymbolName, "sidebar-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = 0;
  instance.frame.y = 0;
  instance.frame.height = rectangle.parent.frame.height;
  overrideLayers(rectangle, instance);
}

function overrideCheckbox(rectangle, symbols) {
  console.log("overriding checkbox");
  var checkboxSymbolName = Settings.documentSettingForKey(document, 'checkbox');
  var symbol = findSymbol(symbols, checkboxSymbolName, "checkbox-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  overrideLayers(rectangle, instance);
}

function overrideText(textlayer, symbols) {
  console.log("overriding text");
  var symbol = findSymbol(symbols, textlayer.text);
  var instance = copyInstance(symbol);
  instance.frame.x = textlayer.frame.x;
  instance.frame.y = textlayer.frame.y + textlayer.frame.height - instance.frame.height;
  overrideLayers(textlayer, instance);
}

function overrideRadioButton(oval, symbols) {
  console.log("overriding radio button");
  var radiobuttonSymbolName = Settings.documentSettingForKey(document, 'radiobutton');
  var symbol = findSymbol(symbols, radiobuttonSymbolName, "radiobutton-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = oval.frame.x;
  instance.frame.y = oval.frame.y;
  overrideLayers(oval, instance);
}

function overrideInput(line, symbols) {
  console.log("overriding input");
  var inputSymbolName = Settings.documentSettingForKey(document, 'input');
  var symbol = findSymbol(symbols, inputSymbolName, "input-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = line.frame.x;
  instance.frame.y = line.frame.y - instance.frame.height;
  overrideLayers(line, instance);
}

function overrideCard(rectangle, symbols) {
  console.log("overriding card");
  var cardSymbolName = Settings.documentSettingForKey(document, 'card');
  var symbol = findSymbol(symbols, cardSymbolName, "card-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  overrideLayers(rectangle, instance);
}

function overrideBackground(rectangle, symbols) {
  console.log("overriding background");
  var backgroundSymbolName = Settings.documentSettingForKey(document, 'background');
  var symbol = findSymbol(symbols, backgroundSymbolName, "background-flp");
  var instance = copyInstance(symbol);
  instance.frame.x = rectangle.frame.x;
  instance.frame.y = rectangle.frame.y;
  instance.frame.height = rectangle.parent.frame.height;
  instance.frame.width = rectangle.parent.frame.width;
  console.log("symbol: " + symbol);
  overrideLayers(rectangle, instance);
}

function isFillEnabled(layer) {
  var length = layer.style.fills.length;

  for (var i = 0; i < length; i++) {
    if (layer.style.fills[i].enabled === true) {
      return 'true';
    }
  }

  return null;
}

function filterRelevantSymbols(layer) {
  var x = layer.frame.x;
  var y = layer.frame.y;
  var width = layer.frame.width;
  var height = layer.frame.height; //TODO: Choose if symbols are from current document or external library

  var symbols = null;

  if (symbolsFromCurrentDoc()) {
    symbols = document.getSymbols();
  } else {
    symbols = allLibraries[libraryIndex].getImportableSymbolReferencesForDocument(document);
  }

  var typeOfLayer = String(layer.sketchObject.class()); //check if text

  if (typeOfLayer === 'MSTextLayer') {
    overrideText(layer, symbols);
    return 1;
  } //check if status bar
  else if (typeOfLayer === 'MSRectangleShape' && x === 0 && y === 0 && width === layer.parent.frame.width && height < 50) {
      overrideStatusbar(layer, symbols);
      return 1;
    } //check if header
    else if (typeOfLayer === 'MSRectangleShape' && x === 0 && y === 0 && width === layer.parent.frame.width && height < layer.parent.frame.height) {
        overrideHeader(layer, symbols);
        return 1;
      } //check if footer
      else if (typeOfLayer === 'MSRectangleShape' && x === 0 && width === layer.parent.frame.width && y + height === layer.parent.frame.height && y > 0) {
          overrideFooter(layer, symbols);
          return 1;
        } //check if sidebar
        else if (typeOfLayer === 'MSRectangleShape' && x === 0 && y === 0 && height === layer.parent.frame.height && width < layer.parent.frame.width) {
            overrideSidebar(layer, symbols);
            return 1;
          } //check if switch button
          else if (typeOfLayer === 'MSRectangleShape' && width >= 60 && width <= 120 && height <= 100) {
              overrideSwitch(layer, symbols);
              return 1;
            } //check if button
            else if (typeOfLayer === 'MSRectangleShape' && width >= 70 && height <= 200) {
                overrideButton(layer, symbols);
                return 1;
              } //check if radio button
              else if (typeOfLayer === 'MSOvalShape' && width <= 50 && height <= 50) {
                  overrideRadioButton(layer, symbols);
                  return 1;
                } //check if checkbox
                else if (typeOfLayer === 'MSRectangleShape' && width <= 50 && height <= 50) {
                    overrideCheckbox(layer, symbols);
                    return 1;
                  } //check if input
                  else if (typeOfLayer === 'MSShapePathLayer' && height <= 3 && width >= 50) {
                      overrideInput(layer, symbols);
                      return 1;
                    } //check if card
                    else if (typeOfLayer === 'MSRectangleShape' && width < layer.parent.frame.width && height < layer.parent.frame.height) {
                        overrideCard(layer, symbols);
                        return 1;
                      } //check if background
                      else if (typeOfLayer === 'MSRectangleShape' && width === layer.parent.frame.width && height === layer.parent.frame.height) {
                          overrideBackground(layer, symbols);
                          return 1;
                        }

  return null;
}

function onRectangle(context) {
  var page = document.selectedPage;
  var layers = document.selectedLayers.layers;
  var symbol;
  var count = 0;

  if (layers.length >= 1) {
    for (var i = 0; i < layers.length; i++) {
      symbol = filterRelevantSymbols(layers[i]);

      if (symbol !== null) {
        count++;
      }
    }

    if (count === 1) {
      sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message(count + " layer replaced with a symbol. 🎉");
    } else {
      sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message(count + " layers replaced with symbols. 🎉");
    }
  } else {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Nothing was selected.");
  }
}

function copyInstance(symbol) {
  if (symbolsFromCurrentDoc()) {
    return symbol.createNewInstance();
  } else {
    console.log(symbol);
    return symbol.import().createNewInstance();
  }
}

function symbolsFromCurrentDoc() {
  return isNaN(libraryIndex) || libraryIndex === "currentFile" || libraryIndex === undefined || libraryIndex === -1;
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=rectangleToSymbol.js.map